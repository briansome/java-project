/*
NAME;
ID:
OTHER INFO
 */
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        reverse("Assignment.csv");
        logAmount(20);
        download("https://icatcare.org/app/uploads/2018/07/Elderly-cats.png", "./");
    }

    // Task One
    public static void reverse(String filename) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();
            Collections.reverse(lines);

            BufferedWriter writer = new BufferedWriter(new FileWriter(filename.split("\\.")[0] + "_reversed.csv"));
            for (String l : lines) {
                writer.write(l + "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Task Three
    public static void logAmount(int amount) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Amount.txt"));
            String lastLine = "", line;
            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }
            reader.close();
            if (lastLine.split(",")[0].equals(Integer.toString(amount))) {
                return;
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter("Amount.txt", true));
            SimpleDateFormat formatter = new SimpleDateFormat("MM-dd HH:mm");
            writer.write(amount + ", " + formatter.format(new Date()) + ", UPDATED\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Task Four
    public static void download(String url, String location) {
        try {
            try (InputStream in = new URL(url).openStream()) {
                File file = new File(location + url.substring(url.lastIndexOf("/")));
                if (file.exists()) {
                    System.out.println("File already exists. Do you want to overwrite it? (yes/no)");
                    Scanner scanner = new Scanner(System.in);
                    String answer = scanner.nextLine();
                    if (!answer.equals("yes")) {
                        file = new File(location + url.substring(url.lastIndexOf("/"), url.lastIndexOf(".")) + "(1)" + url.substring(url.lastIndexOf(".")));
                    }
                }
                Files.copy(in, Paths.get(file.getPath()), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}